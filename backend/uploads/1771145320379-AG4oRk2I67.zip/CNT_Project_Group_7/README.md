This is the reproduction and possibly further improvement of the official pytorch implementation of Paper _'Learning Persistent Community Structures in Dynamic Networks via Topological Data Analysis'_, accepted by The 38th Annual AAAI Conference on Artificial Intelligence (AAAI), 2024. 
This project is being prepared by:- 

Project Group 7
Sayan Das(25CS60R01)
Sayan Khan(25CS60R02)
Varsha Das(25BM6JP57)
Lalchand Mondal(25CS60R77)

## Setup

### Enviroments
* Python (Jupyter notebook) 

### Python requirements
* python=3.8.715
* cudatoolkit=11.6
* pytorch=1.12.1+cu116
* numpy=1.23.4
* matplotlib=3.6.0
* scipy=1.9.3
* networkx=2.8.7
* gudhi=3.6.0

### GitHub repo
https://github.com/SayanDasScientistCoder/CNT_Project_Group_7

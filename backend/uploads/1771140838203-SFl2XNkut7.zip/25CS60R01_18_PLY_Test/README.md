Question 1:- 
Input: Q1_input.xml
Output: output.json
Code:- 25CS60R01_Q1.py

Question 2:- 
Input: Q2_input.json
Code:- 25CS60R01_Q2.py


#!/usr/bin/env python3

"""
CS69202: Design Lab
JSON Parser using PLY

You are expected to COMPLETE the lexer rules,
parser grammar, semantic checks, and dictionary construction.
"""

import sys
import ply.lex as lex
import ply.yacc as yacc


# ============================================================
# Lexer
# ============================================================

tokens = (
    'KEY','VALUE','ARRAY','STRING','NUMBER','BOOLEAN','NULL','LBRACE','RBRACE'
)

# TODO: Define token regex rules here
# Example:
# t_LBRACE = r'\{'

t_ignore = ' \t\r'

t_KEY='[a-zA-Z0-9_]'
t_VALUE='[]'


def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# TODO: Define token functions for STRING, NUMBER, TRUE, FALSE, NULL

def t_error(t):
    print(f"Illegal character '{t.value[0]}' at line {t.lineno}")
    t.lexer.skip(1)

lexer = lex.lex()


# ============================================================
# Parser
# ============================================================

# TODO: Write grammar rules using PLY YACC

def p_value(p):
    '''value : object'''
    # TODO
    pass

# TODO: Add remaining grammar rules here


def p_error(p):
    if p:
        print(f"Syntax error at '{p.value}' (line {p.lineno})")
    else:
        print("Syntax error at end of input")
    sys.exit(1)

parser = yacc.yacc(start='value')


# ============================================================
# Driver Code
# ============================================================

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 parser.py input.json")
        sys.exit(1)

    with open(sys.argv[1], 'r') as f:
        data = f.read()

    try:
        result = parser.parse(data, lexer=lexer)
        print(result)   # Print the resulting Python dictionary
        print("Parsing completed successfully.")
    except Exception as e:
        print("Error:", e)
        sys.exit(1)

if __name__ == "__main__":
    main()

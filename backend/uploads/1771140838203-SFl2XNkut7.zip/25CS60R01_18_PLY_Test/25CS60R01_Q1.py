#!/usr/bin/env python3

"""
CS69202: Design Lab
XML Parser using PLY

You are expected to COMPLETE the lexer rules,
parser grammar, semantic checks, and tree construction.
"""

import sys
import json
import ply.lex as lex
import ply.yacc as yacc

# ============================================================
# Lexer
# ============================================================

tokens = (
    'TAGNAME','LANGULAR','RANGULAR','SLASH','ATTR','EQUALS','ATTRVALUE','TEXT'
)

# TODO: Define token regex rules here
# Example:
# t_LT = r'<'

t_tag_EQUALS=r'='

def t_tag_ATTR(t):
    r'(id)|(class)|(value)'
    return t

def t_tag_ATTRVALUE(t):
    r'\"[a-zA-Z0-9_]+\"'
    return t

def t_LANGULAR(t):
    r'<'
    t.lexer.begin('tag')
    return t

def t_tag_RANGULAR(t):
    r'>'
    t.lexer.begin('INITIAL')
    return t

#def t_RANGULAR(t):
#    r'>'
#    #t.lexer.pop_state()
#    return t


t_tag_SLASH=r'/'
#t_SLASH=r'/'

states=(
    ('tag','exclusive'),
)

allowed_attrs={
    "root":["id"],
    "section":["id","class"],
    "title":[],
    "item":["id","value"],
    "text":[]
}

def t_TEXT(t):
    '[^<]+'
    #print("Text:- ",t)
    return t

def t_tag_TAGNAME(t):
    r'(root)|(section)|(title)|(item)|(text)'
    return t

#def t_TAGNAME(t):
#    r'(root)|(section)|(title)|(item)|(text)'
#    return t


t_ignore = ' \t\n'
t_tag_ignore = ' \t\n'


#def t_newline(t):
#    r'\n+'
#    t.lexer.lineno += len(t.value)

def t_error(t):
    print(f"Illegal character '{t.value[0]}' at line {t.lineno}")
    t.lexer.skip(1)

def t_tag_error(t):
    print(f"Illegal character '{t.value[0]}' at line {t.lineno}")
    t.lexer.skip(1)



lexer = lex.lex()


# ============================================================
# Parser
# ============================================================

# TODO: Write grammar rules using PLY YACC

def p_document(p):
    '''
    document : document element
             | element
             | textTag
    '''

    if len(p)==3:
        l=p[1]+[p[2]]
        p[0]=l
    else:
        p[0] = [p[1]]

def p_textTag(p):
    '''
    textTag : TEXT
    '''
    p[0]={"type":"TEXT","value":p[1]}


# TODO: Add remaining grammar rules here

def p_element(p):
    '''
    element : OPENTAG document CLOSETAG
            | OPENTAG CLOSETAG
    '''

    if len(p)==4:

        if p[1]["tagName"]!=p[3]:
            raise SyntaxError("Tag Mismatch!!")
        
        d={"type":"ELEMENT","tag":p[1]["tagName"],"attributes":p[1]["attributes"],"children":p[2]}
        p[0]=d
    else:
        #d={"type":"TEXT","value":p[1]}
        if p[1]["tagName"]!=p[2]:
            raise SyntaxError("Tag Mismatch!!")
        
        d={"type":"ELEMENT","tag":p[1]["tagName"],"attributes":p[1]["attributes"],"children":[]}
        p[0]=d

def p_OPENTAG(p):
    '''
    OPENTAG : LANGULAR TAGNAME attrList RANGULAR
            | LANGULAR TAGNAME RANGULAR
    '''

    if len(p)==5:
        allowed=allowed_attrs[p[2]]
        for i in p[3].keys():
            if not i in allowed:
                raise SyntaxError("Invalid attributes!!")
        
        d={"tagName":p[2],"attributes":p[3]}
        p[0]=d
    else:
        p[0]={"tagName":p[2],"attributes":{}}

def p_attrList(p):
    '''
    attrList : ATTR EQUALS ATTRVALUE attrList
             | ATTR EQUALS ATTRVALUE
    '''
    if len(p)==5:
        d=p[4]
        d[p[1]]=p[3]
        p[0]=d
    else:
        p[0]={p[1]:p[3]}

def p_CLOSETAG(p):
    '''
    CLOSETAG : LANGULAR SLASH TAGNAME RANGULAR
    '''
    p[0]=p[3]

#def p_root(p):
#    '''
#
#    '''

#def p_empty(p):
#    '''empty :'''
#    pass

def p_error(p):
    if p:
        print(f"Syntax error at '{p.value}' (line {p.lineno})")
    else:
        print("Syntax error at end of input")
    sys.exit(1)

#parser = yacc.yacc(start='document')
parser = yacc.yacc()


# ============================================================
# Driver Code
# ============================================================

def main():
    #if len(sys.argv) != 2:
    #    print("Usage: python3 parser.py input.xml")
    #    sys.exit(1)

    with open(sys.argv[1], 'r') as f:
        data = f.read()
    
    print("Data is:- \n",data)

    #data=input("Please enter XML:- ")
    s=data
    data=""

    for ch in s:
        if ch!='\n':
            data=data+ch

    try:
        #ast = parser.parse(data, lexer=lexer)
        ast = parser.parse(data)
        #with open("output.json", "w") as out:
        #    json.dump(ast.to_dict(), out, indent=2)
        if len(ast)>1:
            raise SyntaxError("Multiple Roots")
        else:
            ast=ast[0]

        if ast["type"]!="ELEMENT":
            raise SyntaxError("3")
        elif ast["tag"]!="root":
            raise SyntaxError("4")
        else:
            sections=ast["children"]

            for i in sections:
                if i["children"]==[]:
                    continue

                if not (i["type"]=="ELEMENT" and i["tag"]=="section"):
                    raise SyntaxError("1")
                else:
                    c=i["children"]
                    for j in c:
                        if j["type"]!="TEXT" and not (j["tag"] in ["title","item","text"]):
                            raise SyntaxError("2")

        print(json.dumps(ast,indent=2))
        print("Parsing completed successfully.")
        with open("output.json", "w") as out:
            json.dump(ast, out, indent=2)

    except Exception as e:
        print("Error:", e)
        sys.exit(1)

if __name__ == "__main__":
    main()

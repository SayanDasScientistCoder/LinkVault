import subprocess
import csv
import os

GEM5 = "/home/jssiddique/gem5/build/ALL/gem5.opt"
CONFIG = "/home/jssiddique/Desktop/CA/configs/cache_config.py"
BINARY = "/home/jssiddique/Desktop/CA/matrix_multiply"

L1D_SIZES = ["16kB", "32kB", "64kB"]

OUTDIR = "part2_results"
os.makedirs(OUTDIR, exist_ok=True)

CSV_FILE = os.path.join(OUTDIR, "results.csv")

with open(CSV_FILE, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["L1D_Size", "Exec_Ticks", "L1D_Hit_Rate"])

    for size in L1D_SIZES:
        print(f"Running simulation for L1D size = {size}")

        cmd = [
            GEM5,
            CONFIG,
            "--l1i_size=16kB",
            f"--l1d_size={size}",
            "--l2_size=256kB",
            "--l1_assoc=4",
            "--l2_assoc=8",
            f"--binary={BINARY}"
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        exec_ticks = None
        for line in result.stdout.splitlines():
            if "Exiting @ tick" in line:
                exec_ticks = int(line.split()[3])
                break

        hit_rate = None
        with open("m5out/stats.txt") as stats:
            hits = misses = None
            for line in stats:
                if "system.cpu.dcache.overallHits" in line:
                    hits = float(line.split()[1])
                if "system.cpu.dcache.overallMisses" in line:
                    misses = float(line.split()[1])
            if hits is not None and misses is not None:
                hit_rate = hits / (hits + misses)

        writer.writerow([size, exec_ticks, hit_rate])

print("Sweep completed. Results saved to part2_results/results.csv")
